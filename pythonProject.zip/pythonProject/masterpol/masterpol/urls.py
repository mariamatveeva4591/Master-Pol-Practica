from django.contrib import admin
from django.urls import path
from django.views.generic import RedirectView
from pol import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('partners/', views.partners_list, name='partners_list'),
    path('partners/add/', views.partner_settings, name='add_partner'),
    path('partners/edit/<int:partner_id>/', views.partner_settings, name='edit_partner'),
    path('partners/history/<int:partner_id>/', views.partner_history, name='partner_history'),
    path('', RedirectView.as_view(url='/partners/')),
]