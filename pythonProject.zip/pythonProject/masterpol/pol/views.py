# функция, которая обрабатывает множество значений (строк) и возвращают одно итоговое значение
from django.shortcuts import render, get_object_or_404, redirect
from django.db.models import Sum
from .models import Partners, Type_partner, Director, Address, Region, Locality, Street, Sale

# Расчет скидки партнера от общего объема продаж
def calculate(partner):
    sales = Sale.objects.filter(partner=partner).aggregate(
        total=Sum('amount_products')
    )['total'] or 0

    if sales >= 300000:
        return 15, sales
    elif sales >= 50000:
        return 10, sales
    elif sales >= 10000:
        return 5, sales
    else:
        return 0, sales

# Отображение страницы со списком всех партнеров и их скидками
def partners_list(request):
    partners = Partners.objects.all().select_related('type', 'director', 'address')
    # Список партнеров с рассчитанной скидкой
    partners_discount = []
    for partner in partners:
        discount, sales = calculate(partner)
        partners_discount.append({
            'partner': partner,
            'sales': sales,
            'discount': discount
        })

    context = {
        'partners_discount': partners_discount
    }
    return render(request, 'partners.html', context)

# Показывает детальную историю продаж конкретного партнера
def partner_history(request, partner_id):
    partner = get_object_or_404(Partners, id=partner_id) # получение партнера по ID или возвращается 404 если не найден
    sales_history = Sale.objects.filter(partner=partner).select_related('products') # получение истории продаж с названием продукта
    discount, sales = calculate(partner) # расчет скидки

    context = {
        'partner': partner,
        'sales_history': sales_history,
        'discount': discount,
        'sales': sales
    }
    return render(request, 'history.html', context)

# Функция для редактирование/создание нового партнера
def partner_settings(request, partner_id=None):
    partner = None
    types = Type_partner.objects.all() # получение всех типов
    # GET-запрос
    if partner_id:
        partner = get_object_or_404(Partners, id=partner_id)

    # POST-запрос
    if request.method == 'POST':
        # Получаем данные из формы
        type_id = request.POST.get('type')
        name = request.POST.get('name')
        inn = request.POST.get('inn')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        rating = request.POST.get('rating')
        # Данные адреса
        index = request.POST.get('index')
        region_name = request.POST.get('region')
        locality_name = request.POST.get('locality')
        street_name = request.POST.get('street')
        house = request.POST.get('house')
        # Данные директора
        last_name = request.POST.get('last_name')
        first_name = request.POST.get('first_name')
        patronymic = request.POST.get('patronymic')

        # Создаем/получаем регион
        region, created = Region.objects.get_or_create(title=region_name)
        # Создаем/получаем населенный пункт
        locality, created = Locality.objects.get_or_create(title=locality_name)
        # Создаем/получаем улицу
        street, created = Street.objects.get_or_create(title=street_name)
        # Создание/обновление адреса
        address, created = Address.objects.get_or_create(
            index=index,
            region=region,
            locality=locality,
            street=street,
            house=house
        )
        # Создание/обновление директора
        director, created = Director.objects.get_or_create(
            last_name=last_name,
            first_name=first_name,
            patronymic=patronymic
        )
        # Создание/обновление партнера
        if partner:
            # Редактирование существующего
            partner.type_id = type_id
            partner.name = name
            partner.inn = inn
            partner.email = email
            partner.phone = phone
            partner.rating = rating
            partner.address = address
            partner.director = director
            partner.save()
        else:
            # Создание нового
            partner = Partners.objects.create(
                type_id=type_id,
                name=name,
                inn=inn,
                email=email,
                phone=phone,
                rating=rating,
                address=address,
                director=director
            )
        return redirect('partners_list')
    context = {
        'partner': partner,
        'types': types,
    }
    return render(request, 'settings.html', context)